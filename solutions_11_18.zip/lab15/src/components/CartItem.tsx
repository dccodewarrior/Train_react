type cartItemProps = {
  title: string;
  price: string;
};
function CartItem(props: cartItemProps) {
  return (
    <p>
      {props.title}:${props.price}
      {/* <button>Remove</button> */}
    </p>
  );
}

export default CartItem;
