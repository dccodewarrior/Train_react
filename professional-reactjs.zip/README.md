# professional-reactjs
Code for Professional ReactJS course by Chris Minnick

## To Test Whether Your Computer is Set Up Correctly
1.  Change the current directory to `setUpTest`.
    
    `cd setUpTest`

1.  Install the dependencies.
    
    `npm install`

1.  Run the test script.
    
    `npm test`

If the tests pass, you're ready to move on.
