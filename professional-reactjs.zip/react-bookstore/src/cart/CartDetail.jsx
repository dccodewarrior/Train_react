export function AddToCart(props) {
  return <div>Adding {props.id} to the cart.</div>;
}

export function CartDetail() {
  return <div>This is cart detail</div>;
}
