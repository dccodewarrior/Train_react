function CartItem({ id, title, price }) {
  return (
    <p>
      ID:{id}
      <br />
      Title: {title}
      <br />
      Price:{price}
    </p>
  );
}

export default CartItem;
