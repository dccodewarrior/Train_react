import "./App.css";
import Footer from "../Footer";
import ClickCounter from "../ClickCounter";
import Header from "./Header";
import ProductList from "./ProductList";
import { CartDetail, AddToCart } from "../cart/CartDetail.jsx";
import Cart from "./Cart.jsx";
//import productsData from "../data/products.json";
import React, { Component, useState } from "react";

class App extends Component {
  constructor(props) {
    super(props);

    this.state = {
      itemsInCart: [],
      products: [],
      loading: false,
    };
    // this.state = {
    //   products: [],
    // };
    this.addToCart = this.addToCart.bind(this);
    this.removeFromCart = this.removeFromCart.bind(this);
    // this.state = { loading: false };
  }

  addToCart(product) {
    let newItems = [...this.state.itemsInCart, product];
    this.setState({ itemsInCart: newItems });
  }

  removeFromCart(idToRemove) {
    let newItems = this.state.itemsInCart.filter(
      (item) => item.id !== idToRemove
    );
    this.setState({ itemsInCart: newItems });
  }

  shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      let j = Math.floor(Math.random() * (i + 1));
      let temp = array[i];
      array[i] = array[j];
      array[j] = temp;
    }
    return array;
  }
  url = "//localhost:5173/data/products.json";

  componentDidMount() {
    this.setState({ loading: true });
    fetch(this.url)
      .then((response) => response.json())
      .then((products) => this.shuffleArray(products))
      .then((products) => {
        this.setState({ products: products, loading: false });
      });
  }

  render() {
    if (this.state.loading) {
      return "Loading........";
    } else {
      return (
        <div className="container">
          <Header />
          <div className="row">
            <div className="col-md-8">
              <ProductList
                addToCart={this.addToCart}
                removeFromCart={this.removeFromCart}
                productCollection={this.state.products}
                itemsInCart={this.state.itemsInCart}
              />
            </div>
            <div className="col-md-4">
              <Cart itemsInCart={this.state.itemsInCart} />
            </div>
          </div>
          <Footer />
        </div>
      );
    }
  }
}

export default App;
