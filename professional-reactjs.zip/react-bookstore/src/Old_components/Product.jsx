function AddProductToCart(id) {
  alert(id);
}

function Product(props) {
  const {
    isInCart,
    id,
    title,
    author,
    published,
    country,
    lang,
    pages,
    image,
    url,
    price,
    addToCart,
    removeFromCart,
  } = props;

  function handleAddClick() {
    addToCart({ id: id, title: title, price: price });
  }

  function handleRemoveClick() {
    console.log("called");
    removeFromCart(id);
  }

  return (
    <div>
      <img
        src={`images/${image}`}
        style={{ width: "150px", height: "200px" }}
        alt="book cover"
      />
      <div>
        <h4>{title}</h4>
        <p>
          by: {author}
          <br />
          published: {published}, {country}
          <br />
          language: {lang}
          <br />
          pages: {pages}
          <br />
          price: ${price}
          <br />
          link: Click<a href={url}> here</a>
        </p>
        {!isInCart ? (
          <button onClick={handleAddClick}>Add to Cart</button>
        ) : (
          <button onClick={handleRemoveClick}>Remove</button>
        )}
        {/* <button onClick={handleClick}>
          {isInCart ? "In Cart" : "Add to Cart"}
        </button> */}
        {/* {isInCart === true ? <h4>In cart</h4> : <button>Add to Cart</button>} */}
      </div>
    </div>
  );
}

export default Product;
