import CartItem from "./CartItem.jsx";

function Cart({ itemsInCart }) {
  return (
    <div>
      <h2>Cart</h2>
      {itemsInCart.map((product) => (
        <CartItem {...product} key={product.id} />
      ))}
      {/* <CartItem />
      <CartItem />
      <CartItem /> */}
      Total: $x USD
      {itemsInCart.reduce(
        (prev, CartItem) => prev + parseFloat(CartItem.price),
        0
      )}{" "}
    </div>
  );
}

export default Cart;
