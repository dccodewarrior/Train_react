import Product from "./Product";

import styles from "./ProductList.module.css";

function ProductList({
  productCollection,
  itemsInCart,
  addToCart,
  removeFromCart,
}) {
  console.log("added by deven itemsInCart.length");
  // alert(itemsInCart.length);
  const localItemsInCart = itemsInCart.map((localitem) => localitem.id);

  return (
    <div>
      <ul className={styles.productList}>
        {productCollection.map((product) => (
          <li key={product.id} className="{styles.productListItems}">
            <Product
              {...product}
              isInCart={localItemsInCart.includes(product.id)}
              itemsInCart={itemsInCart}
              addToCart={addToCart}
              removeFromCart={removeFromCart}
            />
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ProductList;
