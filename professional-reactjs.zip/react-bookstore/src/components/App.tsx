import "./App.css";
import Footer from "../Footer.tsx";
import ClickCounter from "../ClickCounter.jsx";
import Header from "./Header.tsx";
import ProductList from "./ProductList.tsx";
import Cart from "./Cart.tsx";
import React, { useEffect, useState } from "react";
import Book from "./Book.tsx";
import * as actionCreators from "../actions";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";

const mapStateToProps = (state: any, props: any) => {
  return {
    itemsInCart: state.cart.items,
    products: state.products.products,
  };
};

const mapDispatchToProps = (dispatch: any, props: any) => {
  return bindActionCreators(actionCreators, dispatch);
};

function App(props: any) {
  //  const [itemsInCart, setItemsInCart] = useState<Array<Book>>([]);
  //  const [products, setProducts] = useState<Array<Book>>([]);
  const [isLoading, setIsLoading] = useState<Boolean>(false);

  // add a timer
  let timer = "";

  let url = "//localhost:5173/data/products.json";

  // function addToCart(product: Book) {
  //   let newItems = [...itemsInCart, product];
  //   setItemsInCart(newItems);
  // }

  // function removeFromCart(idToRemove: string) {
  //   let newItems = itemsInCart.filter((item) => item.id !== idToRemove);
  //   setItemsInCart(newItems);
  // }

  function shuffleArray(books: Book[]) {
    for (let i = books.length - 1; i > 0; i--) {
      let j = Math.floor(Math.random() * (i + 1));
      let temp = books[i];
      books[i] = books[j];
      books[j] = temp;
    }
    return books;
  }

  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true);
        const response = await fetch(url);
        const json = await response.json();
        const shuffledArray = shuffleArray(json);
        props.loadProducts(shuffledArray);
        setIsLoading(false);
      } catch (e) {
        console.error(e);
      }
    }
    fetchData();
  }, [url]);

  // useEffect(
  //   function () {
  //     if (url !== "") {
  //       fetch(url); // first run will fetch ''
  //     }
  //     const myTimer = setInterval(() => console.log("tick"), 1000);
  //     return () => clearInterval(myTimer);
  //   },
  //   [url]
  // );

  if (isLoading) return <>"Loading........"</>;

  return (
    <div className="container">
      <Header />
      <div className="row">
        <div className="col-md-8">
          <ProductList
            addToCart={props.addToCart}
            removeFromCart={props.removeFromCart}
            productCollection={props.products}
            itemsInCart={props.itemsInCart}
          />
        </div>
        <div className="col-md-4">
          <Cart
            removeFromCart={props.removeFromCart}
            submitCart={props.submitCart}
            itemsInCart={props.itemsInCart}
          />
        </div>
      </div>
      <Footer />
    </div>
  );
}

//export default App;
export default connect(mapStateToProps, mapDispatchToProps)(App);
