import Book from "./Book";

interface IProductProps {
  book: Book;
  isInCart: boolean;
  addToCart: (product: Book) => void;
  removeFromCart: (id: string) => void;
  // If used this way, then change the defragmentation to use book and
  // then use book.id, book.title in respective tags
  // Also change the ...product in ProductList to only "product"
}

type ProductProps = Book & {
  isInCart: boolean;
  addToCart: (product: Book) => void;
  removeFromCart: (id: string) => void;
};



function Product(props: IProductProps) {
  // Defragment the props into individual variables.
  const { book, isInCart, addToCart, removeFromCart } = props;

  // function Product1(props: ProductProps) {
  //   // Defragment the props into individual variables.
  //   const {
  //     isInCart,
  //     id,
  //     title,
  //     author,
  //     published,
  //     country,
  //     lang,
  //     pages,
  //     image,
  //     url,
  //     price,
  //     addToCart,
  //     removeFromCart,
  //   } = props;

  function handleAddClick() {
    addToCart({ id: book.id, title: book.title, price: book.price });
  }

  function handleRemoveClick() {
    console.log("called");
    removeFromCart(book.id);
  }

  return (
    <div>
      <img
        src={`images/${book.image}`}
        style={{ width: "150px", height: "200px" }}
        alt="book cover"
      />
      <div>
        <h4>{book.title}</h4>
        <p>
          by: {book.author}
          <br />
          published: {book.published}, {book.country}
          <br />
          language: {book.lang}
          <br />
          pages: {book.pages}
          <br />
          price: ${book.price}
          <br />
          link: Click<a href={book.url}> here</a>
        </p>
        {!isInCart ? (
          <button onClick={handleAddClick}>Add to Cart</button>
        ) : (
          <button onClick={handleRemoveClick}>Remove</button>
        )}
        {/* <button onClick={handleClick}>
          {isInCart ? "In Cart" : "Add to Cart"}
        </button> */}
        {/* {isInCart === true ? <h4>In cart</h4> : <button>Add to Cart</button>} */}
      </div>
    </div>
  );
}

export default Product;
