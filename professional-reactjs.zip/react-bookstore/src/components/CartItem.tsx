type CartItemProps = {
  id: string;
  title: string;
  price: string;
};

function CartItem(cartItem: CartItemProps) {
  return (
    <p>
      ID:{cartItem.id}
      <br />
      Title: {cartItem.title}
      <br />
      Price:{cartItem.price}
    </p>
  );
}

export default CartItem;
