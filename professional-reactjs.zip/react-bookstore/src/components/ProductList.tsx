import Product from "./Product";
import styles from "./ProductList.module.css";
import PropTypes from "prop-types";
import Book from "./Book";

interface ProductListProps {
  productCollection: Book[] | [];
  itemsInCart: Book[] | [];
  addToCart: (product: Book) => void;
  removeFromCart: (idToRemove: string) => void;
}
function ProductList(props: ProductListProps) {
  const localItemsInCart = props.itemsInCart.map((localitem) => localitem.id);

  return (
    <div>
      <ul className={styles.productList}>
        {props.productCollection.map((product) => (
          <li key={product.id} className={styles.productListItem}>
            <Product
              // {...product}
              book={product}
              isInCart={localItemsInCart.includes(product.id)}
              addToCart={props.addToCart}
              removeFromCart={props.removeFromCart}
            />
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ProductList;
