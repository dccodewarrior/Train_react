import CartItem from "./CartItem.tsx";
import Book from "./Book.tsx";

function Cart(cart: {
  itemsInCart: Book[];
  submitCart: (itemsInCart: Book[]) => void;
  removeFromCart: (itemsInCart: Book[]) => void;
}) {
  return (
    <div>
      <h2>Cart</h2>
      {cart.itemsInCart.map((product) => (
        <CartItem {...product} key={product.id} />
      ))}
      Total: $x USD
      {cart.itemsInCart.reduce(
        (prev, CartItem) => prev + parseFloat(CartItem.price),
        0
      )}{" "}
      <div>
        <button onClick={() => cart.submitCart(cart.itemsInCart)}>
          Check Out
        </button>
      </div>
    </div>
  );
}

export default Cart;
