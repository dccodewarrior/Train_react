function Footer() {
  const footerStyle = {
    backgroundColor: "black",
    color: "white",
    padding: "10px",
    position: "fixed",
    left: "0",
    bottom: "0",
    width: "100%",
  };
  return <p>this is a footer </p>;
}

{
  /* <p style={footerStyle}>this is a footer </p> */
}
export default Footer;
