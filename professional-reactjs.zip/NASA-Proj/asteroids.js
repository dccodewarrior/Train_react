const today = new Date().toISOString().slice(0, 10);

const key = "66XxLATG5cxQiXmDdDeuAJyVsqIoPqnXv0Vg90dk";

const apiURLForRef =
  "https://api.nasa.gov/neo/rest/v1/feed?start_date=START_DATE&api_key=API_KEY";

const NASA_api_URL = `https://api.nasa.gov/neo/rest/v1/feed?start_date=${today}&api_key=${key}`;

let miss_1_distance = {
  astronomical: "0.3841606934",
  lunar: "149.4385097326",
  kilometers: "57469621.470363058",
  miles: "35709966.8885158804",
};

class Asteroid {
  constructor(isHazardous, distance, speed, size) {
    this.isHazardous = isHazardous;
    this.distance = distance;
    this.speed = speed;
    this.size = size;
  }

  static async getAsteroids() {
    try {
      const response = await fetch(NASA_api_URL);
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      const data = await response.json();
      //console.log(data);
      const asteroids = data.near_earth_objects[today];
      asteroids.map((element) => {
        let approach = element.close_approach_data[0];
        //let distance = approach.miss_distance;
        let miss_1_distance = approach.miss_distance;
        let distance = miss_1_distance.kilometers;
        let speed = approach.relative_velocity.kilometers_per_hour;
        let size = element.estimated_diameter.meters.estimated_diameter_max;
        let hazard = element.is_potentially_hazardous_asteroid;
        let hazardous = element.is_potentially_hazardous_asteroid;
        console.log(`
                Hazard: ${hazardous}
                Distance: ${distance} km
                Speed: ${speed} km/h
                Size: ${size} m`);

        //console.log(speed);
      });
    } catch (error) {
      console.log(error);
    }
  }
}
