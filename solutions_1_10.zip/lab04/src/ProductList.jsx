import Product from './Product.jsx';

function ProductList() {
  return (
    <div>
      <Product />
      <Product />
    </div>
  );
}

export default ProductList;
