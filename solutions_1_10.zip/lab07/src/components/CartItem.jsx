function CartItem(props) {
  return <p>Item:$Price</p>;
}

export default CartItem;
